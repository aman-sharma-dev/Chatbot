document.addEventListener('DOMContentLoaded', function () {
    displayInitialWelcome();
});

function displayInitialWelcome() {
    var initialWelcomeMessage = "Welcome to SalesHarbor! Please provide your name and email to start a conversation with me.";
    var messageFormeight = document.getElementById('messageFormeight');

    if (messageFormeight) {
        messageFormeight.innerHTML += '<div class="d-flex justify-content-start mb-4"><div class="img_cont_msg"><img src="./static/images/chatbot.jpg" class="rounded-circle user_img_msg"></div><div class="msg_cotainer">' + initialWelcomeMessage + '</div></div>';
    }
}

function submitForm(event) {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    showLoadingIndicator();

    sendUserDataToServer(name, email);

    event.preventDefault();
}

function showLoadingIndicator() {
    var loadingMessage = document.getElementById('messageFormeight').appendChild(document.createElement('div'));
    loadingMessage.className = 'message bot-message';
    loadingMessage.innerHTML = '<div id="loading" class="loading-container"><div class="snippet" data-title="dot-typing"><div class="stage"><div class="dot-typing"></div></div></div></div>';
}

function sendUserDataToServer(name, email) {
    fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            text: `Name: ${name} Email: ${email}`,
        }),
    })
    .then(response => response.json())
    .then(data => {
        var loadingMessage = document.querySelector('.message.bot-message:last-child');
        if (loadingMessage) {
            loadingMessage.remove();
        }
        displayBotResponse(data.bot_response);

        showChatInterface();

        hideSignupForm();
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function displayBotResponse(message) {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = 'Hi ' + name + '! How may I help you?';
    var date = new Date();
        var hour = date.getHours();
        var minute = date.getMinutes();
        var str_time = hour + ":" + minute;
    var userMessage = `Name: ${name}, Email: ${email}`;
    var userMessageDiv = '<div class="d-flex justify-content-end mb-4"><div class="msg_cotainer_send">' + userMessage + '<span class="msg_time_send">' + str_time + '</span></div><div class="img_cont_msg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z"/></svg></div></div>';

    var botResponseDiv = `<div class="d-flex justify-content-start mb-4"><div class="img_cont_msg"><img src="./static/images/chatbot.jpg" class="rounded-circle user_img_msg"></div><div class="msg_cotainer">`+ message +`</div></div>`;

    var messageFormeight = document.getElementById('messageFormeight');
    if (messageFormeight) {
        messageFormeight.innerHTML += userMessageDiv + botResponseDiv;
    }
}

function showChatInterface() {
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    var message = document.getElementById('messageArea');
    var Sform  = document.getElementById('signupForm');
    Sform.style.display = "none";
    message.style.display = "flex";
    
   
}

function hideSignupForm() {
    var signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.classList.add('hidden');
    }
}
